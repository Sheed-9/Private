import { useState, useEffect } from 'react'
import Login from './components/Login'
import ClientList from './components/ClientList'
import ClientDetail from './components/ClientDetail'
import AddClient from './components/AddClient'

export default function App() {
  const [authed, setAuthed] = useState(false)
  const [view, setView] = useState('list') // list | detail | add
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    if (sessionStorage.getItem('cv_auth') === '1') setAuthed(true)
  }, [])

  const logout = () => {
    sessionStorage.removeItem('cv_auth')
    setAuthed(false)
  }

  if (!authed) return <Login onLogin={() => setAuthed(true)} />

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0f', fontFamily:"'DM Sans',sans-serif", color:'#e2d9f3' }}>
      {/* Top Bar */}
      <div style={{ background:'#0e0b17', borderBottom:'1px solid #1a1625', padding:'16px 28px',
        display:'flex', justifyContent:'space-between', alignItems:'center',
        position:'sticky', top:0, zIndex:100 }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          {view !== 'list' && (
            <button onClick={()=>{setView('list');setSelected(null)}}
              style={{ background:'transparent', color:'#7c6fa0', border:'1px solid #2a2535',
                padding:'6px 14px', borderRadius:8, fontSize:12, cursor:'pointer' }}>
              ← Back
            </button>
          )}
          <span style={{ fontFamily:"'DM Serif Display',serif", fontSize:22, color:'#c4b5fd' }}>ClientVault</span>
          {view === 'detail' && selected && (
            <span style={{ fontSize:13, color:'#3d3852' }}>/ {selected.name}</span>
          )}
        </div>
        <button onClick={logout}
          style={{ background:'transparent', color:'#3d3852', border:'1px solid #1a1625',
            padding:'6px 14px', borderRadius:8, fontSize:11, cursor:'pointer', letterSpacing:1 }}>
          🔒 Lock
        </button>
      </div>

      <div style={{ maxWidth:1000, margin:'0 auto', padding:'28px 20px' }}>
        {view === 'list' && (
          <ClientList
            onSelect={c => { setSelected(c); setView('detail') }}
            onAdd={() => setView('add')}
          />
        )}
        {view === 'add' && (
          <AddClient
            onSave={() => setView('list')}
            onCancel={() => setView('list')}
          />
        )}
        {view === 'detail' && selected && (
          <ClientDetail
            client={selected}
            onBack={() => { setView('list'); setSelected(null) }}
            onDelete={() => { setView('list'); setSelected(null) }}
          />
        )}
      </div>
    </div>
  )
}

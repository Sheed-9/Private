import { useState } from 'react'

export default function Login({ onLogin }) {
  const [pw, setPw] = useState('')
  const [error, setError] = useState(false)

  const attempt = () => {
    if (pw === import.meta.env.VITE_APP_PASSWORD) {
      sessionStorage.setItem('cv_auth', '1')
      onLogin()
    } else {
      setError(true)
      setPw('')
    }
  }

  return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'#0a0a0f' }}>
      <div style={{ width:360, textAlign:'center' }}>
        <div style={{ fontSize:52, marginBottom:12 }}>🗄️</div>
        <div style={{ fontFamily:"'DM Serif Display', serif", fontSize:34, color:'#c4b5fd', marginBottom:6 }}>ClientVault</div>
        <div style={{ fontSize:12, color:'#3d3852', letterSpacing:3, marginBottom:44 }}>YOUR PRIVATE CLIENT HUB</div>

        <input
          type="password"
          placeholder="Enter your password"
          value={pw}
          onChange={e => { setPw(e.target.value); setError(false) }}
          onKeyDown={e => e.key === 'Enter' && attempt()}
          style={{
            width:'100%', background:'#16131f', border:`1.5px solid ${error ? '#ef4444' : '#2a2535'}`,
            color:'#e2d9f3', padding:'14px 18px', borderRadius:10, fontSize:15,
            outline:'none', marginBottom:10, fontFamily:"'DM Sans', sans-serif"
          }}
        />
        {error && <div style={{ color:'#ef4444', fontSize:12, marginBottom:10 }}>Wrong password. Try again.</div>}

        <button
          onClick={attempt}
          style={{
            width:'100%', background:'linear-gradient(135deg,#7c3aed,#4f46e5)', color:'#fff',
            border:'none', padding:14, borderRadius:10, fontSize:15, fontWeight:600, cursor:'pointer'
          }}
        >
          Unlock Vault
        </button>
      </div>
    </div>
  )
}

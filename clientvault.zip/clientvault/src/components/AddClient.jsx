import { useState } from 'react'
import { supabase } from '../lib/supabase'

const inputStyle = {
  background:'#16131f', border:'1px solid #2a2535', color:'#e2d9f3',
  padding:'11px 14px', borderRadius:8, fontSize:13, outline:'none',
  width:'100%', fontFamily:"'DM Sans',sans-serif"
}

export default function AddClient({ onSave, onCancel }) {
  const [form, setForm] = useState({ name:'', email:'', phone:'', company:'', status:'active' })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const save = async () => {
    if (!form.name.trim()) { setError('Name is required.'); return }
    setSaving(true)
    const { error: err } = await supabase.from('clients').insert([form])
    setSaving(false)
    if (err) { setError(err.message); return }
    onSave()
  }

  const set = (k, v) => setForm(f=>({...f,[k]:v}))

  return (
    <div style={{ maxWidth:520 }}>
      <div style={{ fontFamily:"'DM Serif Display',serif", fontSize:28, color:'#c4b5fd', marginBottom:28 }}>New Client</div>
      <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
        {[['Full Name *','name','text'],['Email','email','email'],['Phone','phone','tel'],['Company','company','text']].map(([label,key,type])=>(
          <div key={key}>
            <div style={{ fontSize:11, color:'#5a5670', letterSpacing:1, marginBottom:6 }}>{label.toUpperCase()}</div>
            <input type={type} value={form[key]} onChange={e=>set(key,e.target.value)} style={inputStyle} placeholder={label.replace(' *','')} />
          </div>
        ))}
        <div>
          <div style={{ fontSize:11, color:'#5a5670', letterSpacing:1, marginBottom:6 }}>STATUS</div>
          <select value={form.status} onChange={e=>set('status',e.target.value)} style={inputStyle}>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        {error && <div style={{ color:'#ef4444', fontSize:13 }}>{error}</div>}
        <div style={{ display:'flex', gap:10, marginTop:4 }}>
          <button onClick={save} disabled={saving}
            style={{ background:'linear-gradient(135deg,#7c3aed,#4f46e5)', color:'#fff', border:'none',
              padding:'11px 24px', borderRadius:8, fontSize:14, fontWeight:600, cursor:'pointer', opacity:saving?0.6:1 }}>
            {saving ? 'Saving...' : 'Create Client'}
          </button>
          <button onClick={onCancel} style={{ background:'transparent', color:'#7c6fa0', border:'1px solid #2a2535', padding:'10px 18px', borderRadius:8, fontSize:13, cursor:'pointer' }}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  )
}

import { useState, useEffect, useRef } from 'react'
import { supabase } from '../lib/supabase'
import { Avatar, statusColors } from './ClientList'

const inputStyle = { background:'#16131f', border:'1px solid #2a2535', color:'#e2d9f3', padding:'10px 14px', borderRadius:8, fontSize:13, outline:'none', width:'100%', fontFamily:"'DM Sans',sans-serif" }
const btnPrimary = { background:'linear-gradient(135deg,#7c3aed,#4f46e5)', color:'#fff', border:'none', padding:'9px 18px', borderRadius:8, fontSize:12, fontWeight:600, cursor:'pointer' }
const btnGhost = { background:'transparent', color:'#7c6fa0', border:'1px solid #2a2535', padding:'8px 16px', borderRadius:8, fontSize:12, cursor:'pointer' }

const fileIcon = name => {
  if (!name) return '📁'
  if (name.match(/\.pdf$/i)) return '📄'
  if (name.match(/\.(doc|docx)$/i)) return '📝'
  if (name.match(/\.(xls|xlsx|csv)$/i)) return '📊'
  if (name.match(/\.(ppt|pptx)$/i)) return '📊'
  return '📁'
}

const fmt = d => new Date(d).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})

export default function ClientDetail({ client, onBack, onDelete }) {
  const [tab, setTab] = useState('notes')
  const [notes, setNotes] = useState([])
  const [links, setLinks] = useState([])
  const [files, setFiles] = useState([])
  const [images, setImages] = useState([])
  const [loading, setLoading] = useState(true)
  const [newNote, setNewNote] = useState('')
  const [addingNote, setAddingNote] = useState(false)
  const [newLink, setNewLink] = useState({ label:'', url:'' })
  const [addingLink, setAddingLink] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef()
  const imgRef = useRef()

  useEffect(() => { fetchAll() }, [client.id])

  const fetchAll = async () => {
    setLoading(true)
    const [n, l, f] = await Promise.all([
      supabase.from('notes').select('*').eq('client_id', client.id).order('created_at', { ascending: false }),
      supabase.from('links').select('*').eq('client_id', client.id).order('created_at', { ascending: false }),
      supabase.from('files').select('*').eq('client_id', client.id).order('created_at', { ascending: false }),
    ])
    setNotes(n.data || [])
    setLinks(l.data || [])
    const allFiles = f.data || []
    setFiles(allFiles.filter(f => f.type === 'document'))
    setImages(allFiles.filter(f => f.type === 'image'))
    setLoading(false)
  }

  // Notes
  const addNote = async () => {
    if (!newNote.trim()) return
    const { data } = await supabase.from('notes').insert([{ client_id: client.id, text: newNote }]).select()
    if (data) setNotes([data[0], ...notes])
    setNewNote(''); setAddingNote(false)
  }
  const deleteNote = async id => {
    await supabase.from('notes').delete().eq('id', id)
    setNotes(notes.filter(n => n.id !== id))
  }

  // Links
  const addLink = async () => {
    if (!newLink.label || !newLink.url) return
    const url = newLink.url.startsWith('http') ? newLink.url : 'https://' + newLink.url
    const { data } = await supabase.from('links').insert([{ client_id: client.id, label: newLink.label, url }]).select()
    if (data) setLinks([data[0], ...links])
    setNewLink({ label:'', url:'' }); setAddingLink(false)
  }
  const deleteLink = async id => {
    await supabase.from('links').delete().eq('id', id)
    setLinks(links.filter(l => l.id !== id))
  }

  // File upload
  const uploadFile = async (e, type) => {
    const picked = Array.from(e.target.files)
    if (!picked.length) return
    setUploading(true)
    for (const file of picked) {
      const path = `${client.id}/${Date.now()}-${file.name}`
      const { error } = await supabase.storage.from('client-files').upload(path, file)
      if (!error) {
        const size = file.size < 1024*1024 ? (file.size/1024).toFixed(1)+' KB' : (file.size/1024/1024).toFixed(1)+' MB'
        const { data } = await supabase.from('files').insert([{ client_id: client.id, name: file.name, size, storage_path: path, type }]).select()
        if (data) {
          if (type === 'document') setFiles(prev => [...prev, data[0]])
          else setImages(prev => [...prev, data[0]])
        }
      }
    }
    setUploading(false)
  }

  const deleteFile = async (file) => {
    await supabase.storage.from('client-files').remove([file.storage_path])
    await supabase.from('files').delete().eq('id', file.id)
    if (file.type === 'document') setFiles(files.filter(f => f.id !== file.id))
    else setImages(images.filter(f => f.id !== file.id))
  }

  const getFileUrl = path => supabase.storage.from('client-files').getPublicUrl(path).data.publicUrl

  const handleDeleteClient = async () => {
    await supabase.from('clients').delete().eq('id', client.id)
    onDelete()
  }

  const tabs = [
    { key:'notes', label:`Notes (${notes.length})` },
    { key:'links', label:`Links (${links.length})` },
    { key:'files', label:`Docs (${files.length})` },
    { key:'images', label:`Images (${images.length})` },
  ]

  return (
    <div>
      {/* Header Card */}
      <div style={{ background:'#0e0b17', border:'1px solid #1a1625', borderRadius:14, padding:24, marginBottom:20 }}>
        <div style={{ display:'flex', alignItems:'flex-start', gap:18, flexWrap:'wrap' }}>
          <Avatar name={client.name} size={64} />
          <div style={{ flex:1, minWidth:200 }}>
            <div style={{ fontFamily:"'DM Serif Display',serif", fontSize:26, color:'#e2d9f3' }}>{client.name}</div>
            {client.company && <div style={{ fontSize:13, color:'#7c6fa0', marginTop:2 }}>{client.company}</div>}
            <div style={{ display:'flex', gap:16, marginTop:10, flexWrap:'wrap' }}>
              {client.email && <span style={{ fontSize:12, color:'#5a5670' }}>✉ {client.email}</span>}
              {client.phone && <span style={{ fontSize:12, color:'#5a5670' }}>📞 {client.phone}</span>}
              <span style={{ fontSize:12, color:'#5a5670' }}>📅 {fmt(client.created_at)}</span>
            </div>
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <span style={{ background:statusColors[client.status]+'25', color:statusColors[client.status], border:`1px solid ${statusColors[client.status]}50`, borderRadius:20, padding:'4px 12px', fontSize:11, fontWeight:600, textTransform:'uppercase', letterSpacing:1 }}>
              {client.status}
            </span>
            <button onClick={() => setConfirmDelete(true)} style={{ ...btnGhost, borderColor:'#ef444440', color:'#ef4444', fontSize:11 }}>Delete</button>
          </div>
        </div>
      </div>

      {confirmDelete && (
        <div style={{ background:'#1a0a0a', border:'1px solid #ef444430', borderRadius:10, padding:18, marginBottom:16, display:'flex', alignItems:'center', gap:14, flexWrap:'wrap' }}>
          <span style={{ color:'#fca5a5', fontSize:13 }}>Permanently delete {client.name} and all data?</span>
          <button onClick={handleDeleteClient} style={{ ...btnPrimary, background:'#ef4444' }}>Yes, Delete</button>
          <button onClick={() => setConfirmDelete(false)} style={btnGhost}>Cancel</button>
        </div>
      )}

      {/* Tabs */}
      <div style={{ display:'flex', borderBottom:'1px solid #1a1625', marginBottom:20 }}>
        {tabs.map(t => (
          <button key={t.key} onClick={()=>setTab(t.key)} style={{ padding:'12px 18px', border:'none', background:'transparent',
            color:tab===t.key?'#c4b5fd':'#3d3852', cursor:'pointer', fontSize:13, fontWeight:tab===t.key?600:400,
            borderBottom:tab===t.key?'2px solid #7c3aed':'2px solid transparent' }}>
            {t.label}
          </button>
        ))}
      </div>

      {loading && <div style={{ color:'#3d3852', textAlign:'center', padding:40 }}>Loading...</div>}

      {!loading && (
        <>
          {/* NOTES */}
          {tab === 'notes' && (
            <div>
              {!addingNote
                ? <button onClick={()=>setAddingNote(true)} style={{ ...btnPrimary, marginBottom:16 }}>+ Add Note</button>
                : <div style={{ background:'#0e0b17', border:'1px solid #2a2535', borderRadius:10, padding:16, marginBottom:16 }}>
                  <textarea value={newNote} onChange={e=>setNewNote(e.target.value)} placeholder="Write your note here..." rows={4}
                    style={{ ...inputStyle, resize:'vertical', marginBottom:10 }} />
                  <div style={{ display:'flex', gap:8 }}>
                    <button onClick={addNote} style={btnPrimary}>Save Note</button>
                    <button onClick={()=>{setAddingNote(false);setNewNote('')}} style={btnGhost}>Cancel</button>
                  </div>
                </div>
              }
              {notes.length===0 && <div style={{ color:'#3d3852', textAlign:'center', padding:40 }}>No notes yet.</div>}
              {notes.map(n => (
                <div key={n.id} style={{ background:'#0e0b17', border:'1px solid #1a1625', borderRadius:10, padding:16, marginBottom:10 }}>
                  <div style={{ fontSize:14, color:'#c8c0e0', lineHeight:1.7, whiteSpace:'pre-wrap' }}>{n.text}</div>
                  <div style={{ display:'flex', justifyContent:'space-between', marginTop:10 }}>
                    <span style={{ fontSize:11, color:'#3d3852' }}>{fmt(n.created_at)}</span>
                    <button onClick={()=>deleteNote(n.id)} style={{ background:'none', border:'none', color:'#3d3852', cursor:'pointer', fontSize:12 }}>✕ Delete</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* LINKS */}
          {tab === 'links' && (
            <div>
              {!addingLink
                ? <button onClick={()=>setAddingLink(true)} style={{ ...btnPrimary, marginBottom:16 }}>+ Add Link</button>
                : <div style={{ background:'#0e0b17', border:'1px solid #2a2535', borderRadius:10, padding:16, marginBottom:16 }}>
                  <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
                    <input value={newLink.label} onChange={e=>setNewLink({...newLink,label:e.target.value})} placeholder="Label (e.g. Website)" style={{ ...inputStyle, width:160 }} />
                    <input value={newLink.url} onChange={e=>setNewLink({...newLink,url:e.target.value})} placeholder="URL" style={{ ...inputStyle, flex:1, minWidth:180 }} />
                  </div>
                  <div style={{ display:'flex', gap:8, marginTop:10 }}>
                    <button onClick={addLink} style={btnPrimary}>Save Link</button>
                    <button onClick={()=>{setAddingLink(false);setNewLink({label:'',url:''})}} style={btnGhost}>Cancel</button>
                  </div>
                </div>
              }
              {links.length===0 && <div style={{ color:'#3d3852', textAlign:'center', padding:40 }}>No links saved yet.</div>}
              {links.map(l => (
                <div key={l.id} style={{ background:'#0e0b17', border:'1px solid #1a1625', borderRadius:10, padding:14, marginBottom:10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  <div>
                    <div style={{ fontSize:13, fontWeight:600, color:'#c4b5fd', marginBottom:3 }}>{l.label}</div>
                    <a href={l.url} target="_blank" rel="noopener noreferrer" style={{ fontSize:12, color:'#5a5670', textDecoration:'none' }}>🔗 {l.url}</a>
                  </div>
                  <button onClick={()=>deleteLink(l.id)} style={{ background:'none', border:'none', color:'#3d3852', cursor:'pointer', fontSize:12 }}>✕</button>
                </div>
              ))}
            </div>
          )}

          {/* FILES */}
          {tab === 'files' && (
            <div>
              <input ref={fileRef} type="file" multiple style={{ display:'none' }} onChange={e=>uploadFile(e,'document')} accept=".pdf,.doc,.docx,.txt,.xls,.xlsx,.ppt,.pptx,.csv" />
              <button onClick={()=>fileRef.current.click()} disabled={uploading} style={{ ...btnPrimary, marginBottom:16, opacity:uploading?0.6:1 }}>
                {uploading ? 'Uploading...' : '+ Upload Document'}
              </button>
              {files.length===0 && <div style={{ color:'#3d3852', textAlign:'center', padding:40 }}>No documents yet.<br/><span style={{ fontSize:12 }}>PDF, Word, Excel, PowerPoint, CSV supported.</span></div>}
              {files.map(f => (
                <div key={f.id} style={{ background:'#0e0b17', border:'1px solid #1a1625', borderRadius:10, padding:14, marginBottom:10, display:'flex', alignItems:'center', gap:14 }}>
                  <div style={{ fontSize:28 }}>{fileIcon(f.name)}</div>
                  <div style={{ flex:1 }}>
                    <a href={getFileUrl(f.storage_path)} target="_blank" rel="noopener noreferrer"
                      style={{ fontSize:13, fontWeight:600, color:'#c8c0e0', textDecoration:'none' }}>
                      {f.name}
                    </a>
                    <div style={{ fontSize:11, color:'#3d3852', marginTop:2 }}>{f.size} · {fmt(f.created_at)}</div>
                  </div>
                  <button onClick={()=>deleteFile(f)} style={{ background:'none', border:'none', color:'#3d3852', cursor:'pointer', fontSize:12 }}>✕</button>
                </div>
              ))}
            </div>
          )}

          {/* IMAGES */}
          {tab === 'images' && (
            <div>
              <input ref={imgRef} type="file" multiple accept="image/*" style={{ display:'none' }} onChange={e=>uploadFile(e,'image')} />
              <button onClick={()=>imgRef.current.click()} disabled={uploading} style={{ ...btnPrimary, marginBottom:16, opacity:uploading?0.6:1 }}>
                {uploading ? 'Uploading...' : '+ Upload Images'}
              </button>
              {images.length===0 && <div style={{ color:'#3d3852', textAlign:'center', padding:40 }}>No images yet.</div>}
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(180px,1fr))', gap:12 }}>
                {images.map(img => (
                  <div key={img.id} style={{ position:'relative', borderRadius:10, overflow:'hidden', border:'1px solid #1a1625', aspectRatio:'4/3', background:'#16131f' }}>
                    <img src={getFileUrl(img.storage_path)} alt={img.name} style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                    <div style={{ position:'absolute', bottom:0, left:0, right:0, background:'linear-gradient(transparent,#0a0a0f90)', padding:'12px 8px 6px', fontSize:10, color:'#c8c0e0' }}>{img.name}</div>
                    <button onClick={()=>deleteFile(img)}
                      style={{ position:'absolute', top:6, right:6, background:'#0a0a0fbb', border:'none', color:'#e2d9f3', borderRadius:'50%', width:24, height:24, cursor:'pointer', fontSize:12 }}>✕</button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

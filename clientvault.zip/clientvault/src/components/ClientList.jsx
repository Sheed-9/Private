import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

const statusColors = { active:'#22c55e', inactive:'#6b7280', pending:'#f59e0b' }

const Avatar = ({ name, size=48 }) => {
  const initials = name.split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase()
  const hue = name.split('').reduce((a,c)=>a+c.charCodeAt(0),0) % 360
  return (
    <div style={{ width:size, height:size, borderRadius:'50%', background:`hsl(${hue},55%,35%)`,
      display:'flex', alignItems:'center', justifyContent:'center', fontSize:size*0.35,
      fontWeight:700, color:'#fff', fontFamily:"'DM Serif Display',serif", flexShrink:0 }}>
      {initials}
    </div>
  )
}

export { Avatar, statusColors }

export default function ClientList({ onSelect, onAdd }) {
  const [clients, setClients] = useState([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchClients() }, [])

  const fetchClients = async () => {
    setLoading(true)
    const { data } = await supabase.from('clients').select('*').order('created_at', { ascending: false })
    setClients(data || [])
    setLoading(false)
  }

  const filtered = clients.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.company||'').toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div>
      <div style={{ display:'flex', gap:12, marginBottom:20, alignItems:'center' }}>
        <input
          placeholder="🔍  Search clients or companies..."
          value={search} onChange={e=>setSearch(e.target.value)}
          style={{ flex:1, background:'#16131f', border:'1px solid #2a2535', color:'#e2d9f3',
            padding:'12px 16px', borderRadius:10, fontSize:14, outline:'none', fontFamily:"'DM Sans',sans-serif" }}
        />
        <button onClick={onAdd} style={{ background:'linear-gradient(135deg,#7c3aed,#4f46e5)', color:'#fff',
          border:'none', padding:'12px 20px', borderRadius:10, fontSize:13, fontWeight:600, cursor:'pointer', whiteSpace:'nowrap' }}>
          + New Client
        </button>
      </div>

      {loading && <div style={{ textAlign:'center', color:'#3d3852', padding:60 }}>Loading clients...</div>}

      {!loading && filtered.length === 0 && (
        <div style={{ textAlign:'center', color:'#3d3852', padding:60, fontSize:15 }}>
          {clients.length === 0 ? 'No clients yet. Add your first one!' : 'No results found.'}
        </div>
      )}

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:14 }}>
        {filtered.map(c => (
          <div key={c.id} onClick={()=>onSelect(c)}
            style={{ background:'#0e0b17', border:'1px solid #1a1625', borderRadius:12, padding:20,
              cursor:'pointer', transition:'border-color 0.2s,transform 0.15s' }}
            onMouseEnter={e=>{e.currentTarget.style.borderColor='#7c3aed';e.currentTarget.style.transform='translateY(-2px)'}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor='#1a1625';e.currentTarget.style.transform='none'}}>
            <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:12 }}>
              <Avatar name={c.name} size={44} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontWeight:600, fontSize:15, color:'#e2d9f3', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{c.name}</div>
                <div style={{ fontSize:12, color:'#5a5670', marginTop:2 }}>{c.company||'No company'}</div>
              </div>
              <div style={{ width:8, height:8, borderRadius:'50%', background:statusColors[c.status]||'#6b7280', flexShrink:0 }} />
            </div>
            <div style={{ fontSize:12, color:'#3d3852' }}>{c.email}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
